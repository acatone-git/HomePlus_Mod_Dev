echo "Remounting the product partition as rw"
mount -o remount,rw /
echo "Removing Modified Layout"
rm /system/usr/keylayout/Vendor_0001_Product_0001.kl
echo "Rebooting"
reboot
