echo "Remounting the product partition as rw"
mount -o remount,rw /
echo "Copying Modified Layout"
cp /storage/emulated/0/split.kl /system/usr/keylayout/Vendor_0001_Product_0001.kl
echo "Activating Modified Layout"
chmod 644 /system/usr/keylayout/*
echo "Rebooting"
reboot
